import { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  ShoppingBag, User, Menu, X, Clock, MapPin, Phone, 
  Truck, Star, Calendar, Search, Plus, Minus, ChevronDown,
  Flame, CheckCircle, Utensils, Award, Instagram, Facebook, Twitter
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

gsap.registerPlugin(ScrollTrigger);

// Types
interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: string;
  badge?: string;
}

interface Review {
  id: number;
  name: string;
  rating: number;
  text: string;
  date: string;
}

// Menu Data
const menuItems: MenuItem[] = [
  // Meals
  { id: 'm1', name: 'Chicken Burger Meal', description: 'Burger with fries & drink', price: 6.99, category: 'meals', badge: 'Popular' },
  { id: 'm2', name: 'Tower Burger Meal', description: 'Double stacked with cheese', price: 7.49, category: 'meals' },
  { id: 'm3', name: '6 Wings Meal', description: '6 wings with fries & drink', price: 6.49, category: 'meals', badge: 'Bestseller' },
  { id: 'm4', name: '8 Wings Meal', description: '8 wings with fries & drink', price: 7.49, category: 'meals' },
  { id: 'm5', name: 'Chicken Wrap Meal', description: 'Wrap with fries & drink', price: 6.49, category: 'meals' },
  { id: 'm6', name: '2pc Chicken Meal', description: '2 pieces with fries', price: 5.99, category: 'meals' },
  { id: 'm7', name: '3pc Chicken Meal', description: '3 pieces with fries', price: 7.49, category: 'meals' },
  { id: 'm8', name: 'Variety Box', description: '1pc chicken, 3 wings & chips', price: 5.99, category: 'meals' },
  
  // Burgers
  { id: 'b1', name: 'Chicken Burger', description: 'Grilled chicken with fresh lettuce and mayo', price: 6.49, category: 'burgers', badge: 'Bestseller' },
  { id: 'b2', name: 'Tower Burger', description: 'Double stacked with cheese and bacon', price: 6.99, category: 'burgers' },
  { id: 'b3', name: 'Ringer Burger', description: 'Onion ring topped chicken burger', price: 6.99, category: 'burgers' },
  { id: 'b4', name: 'BBQ Chicken Burger', description: 'BBQ glazed chicken burger', price: 6.99, category: 'burgers' },
  { id: 'b5', name: 'Spicy Burger', description: 'Spicy chicken with jalapenos', price: 6.99, category: 'burgers', badge: 'Hot' },
  { id: 'b6', name: 'Veg Burger', description: 'Vegetarian burger with fries', price: 6.49, category: 'burgers' },
  
  // Wings
  { id: 'w1', name: '4 Wings Meal', description: '4 crispy wings with fries & drink', price: 4.49, category: 'wings' },
  { id: 'w2', name: '6 Wings Meal', description: '6 crispy wings with fries & drink', price: 6.49, category: 'wings', badge: 'Popular' },
  { id: 'w3', name: '8 Wings Meal', description: '8 crispy wings with fries & drink', price: 7.49, category: 'wings' },
  { id: 'w4', name: '12 Wings Meal', description: '12 wings with fries & drink', price: 9.49, category: 'wings', badge: 'Bestseller' },
  { id: 'w5', name: 'BBQ Wings (6)', description: 'BBQ glazed wings with fries', price: 6.99, category: 'wings' },
  { id: 'w6', name: 'Peri Peri Wings (6)', description: 'Spicy peri peri wings with fries', price: 7.49, category: 'wings', badge: 'Hot' },
  
  // Pizzas
  { id: 'p1', name: 'Margherita', description: 'Pizza sauce & mozzarella cheese', price: 8.99, category: 'pizzas' },
  { id: 'p2', name: 'Double Pepperoni', description: 'Cheese & double pepperoni', price: 9.99, category: 'pizzas', badge: 'Popular' },
  { id: 'p3', name: 'BBQ Meat Feast', description: 'Chicken, sausage, ham, bacon & pepperoni', price: 11.99, category: 'pizzas' },
  { id: 'p4', name: 'Club Chicken', description: 'Onion, bacon & tomato', price: 10.99, category: 'pizzas' },
  { id: 'p5', name: 'American Hot', description: 'Pepperoni & jalapeno', price: 10.99, category: 'pizzas', badge: 'Hot' },
  { id: 'p6', name: 'Garden Party', description: 'Vegetarian - peppers, mushrooms, tomato', price: 9.99, category: 'pizzas' },
  
  // Indian Curries
  { id: 'i1', name: 'Chicken Tikka Masala', description: 'Creamy tomato sauce with tender chicken', price: 11.99, category: 'indian', badge: 'Chef Special' },
  { id: 'i2', name: 'Butter Chicken', description: 'Rich buttery tomato curry', price: 12.49, category: 'indian', badge: 'Popular' },
  { id: 'i3', name: 'Lamb Curry', description: 'Traditional lamb curry with spices', price: 13.99, category: 'indian' },
  { id: 'i4', name: 'Lamb Madras', description: 'Hot South Indian curry', price: 13.99, category: 'indian', badge: 'Hot' },
  { id: 'i5', name: 'Vegetable Korma', description: 'Mild creamy vegetable curry', price: 10.99, category: 'indian' },
  { id: 'i6', name: 'Chicken Biryani', description: 'Fragrant rice with spiced chicken', price: 12.99, category: 'indian' },
  { id: 'i7', name: 'Sag Aloo', description: 'Spinach and potato curry', price: 9.99, category: 'indian' },
  { id: 'i8', name: 'Chana Masala', description: 'Chickpea curry with spices', price: 9.99, category: 'indian' },
  
  // Extras
  { id: 'e1', name: 'Regular Fries', description: 'Crispy golden fries', price: 1.99, category: 'extras' },
  { id: 'e2', name: 'Large Fries', description: 'Large portion of fries', price: 2.99, category: 'extras' },
  { id: 'e3', name: 'Onion Rings (10)', description: 'Crispy onion rings', price: 3.49, category: 'extras' },
  { id: 'e4', name: 'Mozzarella Sticks', description: 'Cheesy mozzarella sticks', price: 3.49, category: 'extras' },
  { id: 'e5', name: 'Potato Wedges', description: 'Seasoned potato wedges', price: 2.99, category: 'extras' },
  { id: 'e6', name: 'Garlic Naan', description: 'Fresh garlic naan bread', price: 2.99, category: 'extras' },
  { id: 'e7', name: 'Coleslaw', description: 'Fresh creamy coleslaw', price: 1.49, category: 'extras' },
];

// Reviews Data
const reviews: Review[] = [
  { id: 1, name: 'Sarah M.', rating: 5, text: 'Amazing food! The chicken tikka masala was absolutely delicious. Will definitely be ordering again.', date: '2 weeks ago' },
  { id: 2, name: 'James K.', rating: 5, text: 'Best wings in London! The peri peri wings are to die for. Fast delivery too.', date: '1 month ago' },
  { id: 3, name: 'Amina H.', rating: 4, text: 'Great variety on the menu. Love that they have both Indian and fast food options.', date: '3 weeks ago' },
  { id: 4, name: 'David R.', rating: 5, text: 'The mixed grill platter is incredible. Perfect for sharing with friends.', date: '2 months ago' },
  { id: 5, name: 'Lisa T.', rating: 5, text: 'Best burger I have had in ages! The tower burger is massive and tasty.', date: '1 week ago' },
  { id: 6, name: 'Mohammed A.', rating: 4, text: 'Authentic Indian flavors. The biryani reminds me of home.', date: '1 month ago' },
];

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [orderType, setOrderType] = useState<'collection' | 'delivery' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<{name: string; email: string} | null>(null);
  
  const heroRef = useRef<HTMLDivElement>(null);
  const productRefs = useRef<(HTMLDivElement | null)[]>([]);
  const menuRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);

  // GSAP Animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero Animation
      gsap.fromTo('.hero-title-line', 
        { y: 100, opacity: 0 },
        { y: 0, opacity: 1, duration: 1, stagger: 0.2, ease: 'power3.out', delay: 0.3 }
      );
      
      gsap.fromTo('.hero-subtitle',
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.8 }
      );
      
      gsap.fromTo('.hero-buttons',
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 1 }
      );
      
      gsap.fromTo('.hero-badge',
        { scale: 0, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.6, ease: 'back.out(1.7)', delay: 0.5 }
      );

      // Parallax Hero Background
      gsap.to('.hero-bg-image', {
        yPercent: 30,
        ease: 'none',
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true
        }
      });

      // Product Sections
      productRefs.current.forEach((ref, index) => {
        if (ref) {
          const image = ref.querySelector('.product-image');
          const content = ref.querySelector('.product-content');
          const isEven = index % 2 === 0;
          
          gsap.fromTo(image,
            { x: isEven ? -100 : 100, opacity: 0 },
            {
              x: 0, opacity: 1, duration: 1, ease: 'power3.out',
              scrollTrigger: {
                trigger: ref,
                start: 'top 80%',
                toggleActions: 'play none none reverse'
              }
            }
          );
          
          gsap.fromTo(content,
            { x: isEven ? 100 : -100, opacity: 0 },
            {
              x: 0, opacity: 1, duration: 1, ease: 'power3.out', delay: 0.2,
              scrollTrigger: {
                trigger: ref,
                start: 'top 80%',
                toggleActions: 'play none none reverse'
              }
            }
          );
          
          // Parallax on images
          gsap.to(image, {
            yPercent: -10,
            ease: 'none',
            scrollTrigger: {
              trigger: ref,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true
            }
          });
        }
      });

      // Menu Section
      gsap.fromTo('.menu-header',
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
          scrollTrigger: {
            trigger: menuRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // CTA Section
      gsap.fromTo('.cta-content',
        { y: 50, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
          scrollTrigger: {
            trigger: ctaRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );
      
      gsap.fromTo('.info-card',
        { y: 30, opacity: 0 },
        {
          y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out',
          scrollTrigger: {
            trigger: ctaRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Contact Section
      gsap.fromTo('.contact-info',
        { x: -50, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
          scrollTrigger: {
            trigger: contactRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );
      
      gsap.fromTo('.contact-form',
        { x: 50, opacity: 0 },
        {
          x: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.2,
          scrollTrigger: {
            trigger: contactRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    });

    return () => ctx.revert();
  }, []);

  // Cart Functions
  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Filtered Menu Items
  const filteredItems = menuItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  // Login Handler
  const handleLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    setUser({ name, email });
    setIsLoginOpen(false);
  };

  // Reservation Handler
  const handleReservation = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert('Reservation submitted successfully! We will confirm shortly.');
    setIsReservationOpen(false);
  };

  // Scroll to section
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'meals', label: 'Meals' },
    { id: 'burgers', label: 'Burgers' },
    { id: 'wings', label: 'Wings' },
    { id: 'pizzas', label: 'Pizzas' },
    { id: 'indian', label: 'Indian' },
    { id: 'extras', label: 'Extras' },
  ];

  const products = [
    { id: 1, name: 'BURGERS', description: 'Juicy grilled chicken patty, fresh lettuce, tomato, signature sauce on toasted brioche.', price: 'From £4.49', image: '/burger.jpg', badge: 'Bestseller' },
    { id: 2, name: 'WINGS', description: 'Crispy, juicy, and packed with flavor. Choose from BBQ, Spicy, or Peri Peri.', price: 'From £4.49', image: '/wings.jpg', badge: 'Hot & Spicy' },
    { id: 3, name: 'WRAPS', description: 'Grilled chicken or veg, fresh salad, signature sauce in a warm tortilla wrap.', price: 'From £6.49', image: '/wrap.jpg' },
    { id: 4, name: 'GRILLED CHICKEN', description: 'Marinated overnight, flame-grilled to perfection. Served with fries or rice.', price: 'From £4.49', image: '/chicken.jpg', badge: 'Signature' },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A]/80 backdrop-blur-lg border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <a href="#" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#FF6B4A] rounded-lg flex items-center justify-center">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight">MIX-N-GRILL</span>
            </a>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection('menu')} className="text-sm font-medium hover:text-[#FF6B4A] transition-colors">Menu</button>
              <button onClick={() => scrollToSection('order')} className="text-sm font-medium hover:text-[#FF6B4A] transition-colors">Order</button>
              <button onClick={() => scrollToSection('reviews')} className="text-sm font-medium hover:text-[#FF6B4A] transition-colors">Reviews</button>
              <button onClick={() => scrollToSection('contact')} className="text-sm font-medium hover:text-[#FF6B4A] transition-colors">Contact</button>
            </div>
            
            {/* Actions */}
            <div className="flex items-center gap-3">
              <button 
                onClick={() => user ? setUser(null) : setIsLoginOpen(true)}
                className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <User className="w-4 h-4" />
                <span className="text-sm">{user ? user.name : 'Login'}</span>
              </button>
              
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 rounded-lg bg-[#FF6B4A] hover:bg-[#E85A3A] transition-colors"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-white text-[#0A0A0A] text-xs font-bold rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
              
              <button 
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-lg bg-white/5"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-[#0A0A0A] border-t border-white/5">
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => scrollToSection('menu')} className="block w-full text-left py-2 text-sm font-medium">Menu</button>
              <button onClick={() => scrollToSection('order')} className="block w-full text-left py-2 text-sm font-medium">Order</button>
              <button onClick={() => scrollToSection('reviews')} className="block w-full text-left py-2 text-sm font-medium">Reviews</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left py-2 text-sm font-medium">Contact</button>
              <button onClick={() => setIsLoginOpen(true)} className="block w-full text-left py-2 text-sm font-medium">Login</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img 
            src="/hero-bg.jpg" 
            alt="Grilled Chicken" 
            className="hero-bg-image w-full h-full object-cover scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0A]/70 via-[#0A0A0A]/50 to-[#0A0A0A]" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A]/80 via-transparent to-[#0A0A0A]/80" />
        </div>
        
        {/* Decorative Glow */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF6B4A]/20 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-[#FF6B4A]/10 rounded-full blur-[100px] pointer-events-none" />
        
        {/* Content */}
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto pt-20">
          <div className="hero-badge inline-flex items-center gap-2 px-4 py-2 bg-[#FF6B4A]/20 border border-[#FF6B4A]/30 rounded-full mb-6">
            <Flame className="w-4 h-4 text-[#FF6B4A]" />
            <span className="text-sm font-medium text-[#FF6B4A]">NOW OPEN</span>
          </div>
          
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6">
            <span className="hero-title-line block">MIX N</span>
            <span className="hero-title-line block text-[#FF6B4A] text-glow">GRILL</span>
          </h1>
          
          <p className="hero-subtitle text-lg sm:text-xl md:text-2xl text-white/80 max-w-2xl mx-auto mb-4">
            Premium grilled chicken, burgers, wings & Indian cuisine—made fresh and delivered hot to your door.
          </p>
          
          <p className="hero-subtitle text-sm text-white/60 mb-8 flex items-center justify-center gap-2">
            <MapPin className="w-4 h-4" />
            141 Manchester Road, London E14 3DN
          </p>
          
          <div className="hero-buttons flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => scrollToSection('order')} className="btn btn-primary">
              Order Now
            </button>
            <button onClick={() => scrollToSection('menu')} className="btn btn-outline">
              View Menu
            </button>
            <button onClick={() => setIsReservationOpen(true)} className="btn btn-ghost">
              <Calendar className="w-4 h-4" />
              Book Table
            </button>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-center">
          <span className="text-xs text-white/50 uppercase tracking-widest mb-2 block">Scroll to explore</span>
          <ChevronDown className="w-6 h-6 text-white/50 scroll-bounce mx-auto" />
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4 bg-[#0A0A0A] relative">
        <div className="noise-overlay" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="section-tag">Our Story</span>
          <h2 className="section-title mb-6">A NEW CHAPTER</h2>
          <p className="text-white/70 text-lg leading-relaxed mb-6">
            We are Now Mix N Grill! Formerly known as The Gaylord Indian Restaurant, we have rebranded to Mix N Grill Indian Restaurant under new management but still same much loved chef! Our new name reflects our expanded menu!
          </p>
          <p className="text-white/70 leading-relaxed mb-6">
            We continue to serve your favourite authentic Indian & Bangladeshi cuisine, now alongside a variety of new & delicious fast food options including grilled Halal meats and various pizza offerings. We also offer an extensive range of ice creams, desserts and milkshakes.
          </p>
          <p className="text-white/70 leading-relaxed">
            We are still at the same convenient location: 141 Manchester Road, E14 3DN, London. Come and visit us @ Mix N Grill Indian restaurant and explore what is new on our menu — while still enjoying the flavours you love for the last 35+ years.
          </p>
        </div>
      </section>

      {/* Product Showcase Sections */}
      <section className="py-20 bg-[#0A0A0A]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="section-tag">Our Specialties</span>
            <h2 className="section-title">SIGNATURE <span className="accent">DISHES</span></h2>
          </div>
          
          <div className="space-y-24">
            {products.map((product, index) => (
              <div 
                key={product.id}
                ref={el => { productRefs.current[index] = el; }}
                className={`grid md:grid-cols-2 gap-8 md:gap-16 items-center ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}
              >
                {/* Image */}
                <div className={`relative ${index % 2 === 1 ? 'md:order-2' : ''}`}>
                  <div className="product-image relative overflow-hidden rounded-2xl group">
                    <img 
                      src={product.image} 
                      alt={product.name}
                      className="w-full aspect-[3/4] object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A]/60 to-transparent" />
                    
                    {product.badge && (
                      <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-bold ${
                        product.badge === 'Hot & Spicy' ? 'bg-gradient-to-r from-[#FF4D2E] to-[#FF8C00]' : 'bg-[#FF6B4A]'
                      }`}>
                        {product.badge}
                      </div>
                    )}
                  </div>
                  
                  {/* Decorative Line */}
                  <div className={`absolute -bottom-4 ${index % 2 === 0 ? '-right-4' : '-left-4'} w-32 h-1 bg-[#FF6B4A]`} />
                </div>
                
                {/* Content */}
                <div className={`product-content ${index % 2 === 1 ? 'md:order-1 md:text-right' : ''}`}>
                  <h3 className="text-3xl md:text-4xl font-bold mb-4">{product.name}</h3>
                  <p className="text-white/70 text-lg mb-6 leading-relaxed">{product.description}</p>
                  <div className="text-2xl font-bold text-[#FF6B4A] mb-6">{product.price}</div>
                  <button 
                    onClick={() => addToCart(menuItems.find(m => m.name.includes(product.name.split(' ')[0])) || menuItems[0])}
                    className="btn btn-primary"
                  >
                    <Plus className="w-4 h-4" />
                    Add to Order
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" ref={menuRef} className="py-20 bg-[#0A0A0A] relative">
        <div className="noise-overlay" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="menu-header text-center mb-12">
            <span className="section-tag">Explore</span>
            <h2 className="section-title">OUR <span className="accent">MENU</span></h2>
          </div>
          
          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
              <input
                type="text"
                placeholder="Search menu items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-input pl-12"
              />
            </div>
          </div>
          
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeCategory === cat.id 
                    ? 'bg-[#FF6B4A] text-white' 
                    : 'bg-white/5 text-white/70 hover:bg-white/10'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
          
          {/* Menu Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems.map((item, index) => (
              <div 
                key={item.id}
                className="card group relative bg-[#1A1A1A] p-4 rounded-xl hover:shadow-[0_0_30px_rgba(255,107,74,0.2)] transition-all duration-300"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {item.badge && (
                  <div className={`absolute top-3 right-3 px-2 py-1 rounded text-xs font-bold ${
                    item.badge === 'Hot' ? 'bg-[#FF4D2E]' : 'bg-[#FF6B4A]'
                  }`}>
                    {item.badge}
                  </div>
                )}
                
                <div className="mb-3">
                  <h4 className="font-bold text-lg mb-1">{item.name}</h4>
                  <p className="text-white/60 text-sm line-clamp-2">{item.description}</p>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-[#FF6B4A] font-bold text-lg">£{item.price.toFixed(2)}</span>
                  <button 
                    onClick={() => addToCart(item)}
                    className="w-10 h-10 rounded-lg bg-[#FF6B4A] hover:bg-[#E85A3A] flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0"
                  >
                    <Plus className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          {filteredItems.length === 0 && (
            <div className="text-center py-12">
              <p className="text-white/50">No items found matching your search.</p>
            </div>
          )}
        </div>
      </section>

      {/* Order CTA Section */}
      <section id="order" ref={ctaRef} className="py-20 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src="/platter.jpg" alt="Mixed Grill" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0A0A0A]/90 via-[#0A0A0A]/70 to-[#0A0A0A]/90" />
        </div>
        
        {/* Glow Effect */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#FF6B4A]/30 rounded-full blur-[150px] pointer-events-none" />
        
        <div className="cta-content relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="section-tag">Ready to Order?</span>
              <h2 className="section-title">GET YOUR <span className="accent">FOOD</span> DELIVERED</h2>
              <p className="text-white/70 text-lg mb-8">
                Fresh, hot, and delicious food delivered straight to your door. Order now and taste the difference.
              </p>
              <button onClick={() => setIsCheckoutOpen(true)} className="btn btn-primary btn-lg">
                Start Your Order
              </button>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { icon: Clock, title: 'Open Daily', text: '10:30am – 11:30pm' },
                { icon: Truck, title: 'Fast Delivery', text: '30-45 minutes' },
                { icon: MapPin, title: 'Location', text: '141 Manchester Rd, E14 3DN' },
                { icon: Phone, title: 'Call Us', text: '020 7538 0393' },
              ].map((info, i) => (
                <div key={i} className="info-card bg-white/5 backdrop-blur-sm p-4 rounded-xl hover:bg-white/10 transition-colors">
                  <info.icon className="w-8 h-8 text-[#FF6B4A] mb-3" />
                  <h4 className="font-bold mb-1">{info.title}</h4>
                  <p className="text-white/60 text-sm">{info.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 bg-[#0A0A0A] relative">
        <div className="noise-overlay" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <span className="section-tag">Testimonials</span>
            <h2 className="section-title">WHAT OUR <span className="accent">CUSTOMERS</span> SAY</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review) => (
              <div key={review.id} className="card bg-[#1A1A1A] p-6 rounded-xl">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i < review.rating ? 'text-[#D4AF37] fill-[#D4AF37]' : 'text-white/20'}`} 
                    />
                  ))}
                </div>
                <p className="text-white/80 mb-4 leading-relaxed">{review.text}</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold">{review.name}</span>
                  <span className="text-white/50 text-sm">{review.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hygiene Rating Section */}
      <section className="py-20 bg-[#0A0A0A]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#1A1A1A] rounded-2xl p-8 md:p-12 text-center">
            <span className="section-tag">Food Safety</span>
            <h2 className="section-title mb-6">UK HYGIENE <span className="accent">RATING</span></h2>
            
            <div className="flex flex-col md:flex-row items-center justify-center gap-8 mb-8">
              <div className="w-32 h-32 bg-[#4ade80] rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-5xl font-bold text-[#0A0A0A]">5</div>
                  <div className="text-xs font-bold text-[#0A0A0A]">VERY GOOD</div>
                </div>
              </div>
              
              <div className="text-left">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-[#4ade80]" />
                  <span>Hygienic food handling</span>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-[#4ade80]" />
                  <span>Clean premises</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-[#4ade80]" />
                  <span>Food safety management</span>
                </div>
              </div>
            </div>
            
            <p className="text-white/60 text-sm">
              Inspected by London Borough of Tower Hamlets Food Safety Team
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" ref={contactRef} className="py-20 bg-[#0A0A0A] relative">
        <div className="noise-overlay" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="contact-info">
              <span className="section-tag">Get in Touch</span>
              <h2 className="section-title">VISIT <span className="accent">US</span></h2>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B4A]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#FF6B4A]" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Address</h4>
                    <p className="text-white/60">141 Manchester Road<br />Island Gardens, London<br />E14 3DN</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B4A]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#FF6B4A]" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Phone</h4>
                    <p className="text-white/60">020 7538 0393<br />020 7538 9826</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B4A]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-[#FF6B4A]" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Hours</h4>
                    <p className="text-white/60">Open Daily: 10:30am – 11:30pm<br />Delivery: 5pm – 11:30pm</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#FF6B4A]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Award className="w-6 h-6 text-[#FF6B4A]" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Service Options</h4>
                    <p className="text-white/60">Vegan options • Kids menu<br />Dogs allowed outside</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Contact Form */}
            <div className="contact-form bg-[#1A1A1A] p-8 rounded-2xl">
              <span className="section-tag">Send a Message</span>
              <h3 className="text-2xl font-bold mb-6">CONTACT <span className="accent">US</span></h3>
              
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input type="text" placeholder="Your name" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input type="email" placeholder="you@example.com" className="form-input" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message</label>
                  <textarea placeholder="How can we help?" rows={4} className="form-input resize-none" />
                </div>
                <button type="submit" className="btn btn-primary w-full">
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-[#0A0A0A] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#FF6B4A] rounded-lg flex items-center justify-center">
                <Flame className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">MIX-N-GRILL</span>
            </div>
            
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-[#FF6B4A] transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-[#FF6B4A] transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-[#FF6B4A] transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
            
            <p className="text-white/50 text-sm">© 2024 Mix-N-Grill. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <div className={`fixed inset-y-0 right-0 w-full max-w-md bg-[#1A1A1A] shadow-2xl transform transition-transform duration-300 z-[60] ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-6 border-b border-white/5">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              Your Cart
            </h3>
            <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-white/5 rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="flex-1 overflow-auto p-6">
            {cart.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingBag className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <p className="text-white/50">Your cart is empty</p>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map(item => (
                  <div key={item.id} className="flex items-center gap-4 bg-white/5 p-4 rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-bold">{item.name}</h4>
                      <p className="text-[#FF6B4A]">£{(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 bg-white/10 rounded flex items-center justify-center hover:bg-white/20">
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 bg-white/10 rounded flex items-center justify-center hover:bg-white/20">
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="p-2 text-white/50 hover:text-[#FF6B4A]">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {cart.length > 0 && (
            <div className="p-6 border-t border-white/5">
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-bold">Total</span>
                <span className="text-2xl font-bold text-[#FF6B4A]">£{cartTotal.toFixed(2)}</span>
              </div>
              <button onClick={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }} className="btn btn-primary w-full">
                Checkout
              </button>
            </div>
          )}
        </div>
      </div>
      
      {isCartOpen && <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[55]" onClick={() => setIsCartOpen(false)} />}

      {/* Login Dialog */}
      <Dialog open={isLoginOpen} onOpenChange={setIsLoginOpen}>
        <DialogContent className="bg-[#1A1A1A] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Customer Login</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleLogin} className="space-y-4 mt-4">
            <div>
              <label className="block text-sm font-medium mb-2">Name</label>
              <Input name="name" placeholder="Your name" className="form-input border-0" required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email</label>
              <Input name="email" type="email" placeholder="you@example.com" className="form-input border-0" required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Phone</label>
              <Input name="phone" placeholder="020 0000 0000" className="form-input border-0" />
            </div>
            <Button type="submit" className="btn btn-primary w-full mt-6">
              Login
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reservation Dialog */}
      <Dialog open={isReservationOpen} onOpenChange={setIsReservationOpen}>
        <DialogContent className="bg-[#1A1A1A] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Book a Table</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleReservation} className="space-y-4 mt-4">
            <div>
              <label className="block text-sm font-medium mb-2">Name</label>
              <Input name="name" placeholder="Your name" className="form-input border-0" required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Phone</label>
              <Input name="phone" placeholder="020 0000 0000" className="form-input border-0" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Date</label>
                <Input name="date" type="date" className="form-input border-0" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Time</label>
                <Input name="time" type="time" className="form-input border-0" required />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Guests</label>
              <Input name="guests" type="number" min="1" max="20" placeholder="Number of guests" className="form-input border-0" required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Special Requests</label>
              <textarea name="notes" placeholder="Any special requests..." rows={3} className="form-input resize-none" />
            </div>
            <Button type="submit" className="btn btn-primary w-full mt-6">
              <Calendar className="w-4 h-4 mr-2" />
              Book Table
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Checkout Dialog */}
      <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <DialogContent className="bg-[#1A1A1A] border-white/10 text-white max-w-lg max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">Checkout</DialogTitle>
          </DialogHeader>
          
          <div className="mt-4 space-y-6">
            {/* Order Summary */}
            <div className="bg-white/5 p-4 rounded-lg">
              <h4 className="font-bold mb-3">Order Summary</h4>
              {cart.length === 0 ? (
                <p className="text-white/50">Your cart is empty</p>
              ) : (
                <div className="space-y-2">
                  {cart.map(item => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>{item.name} x{item.quantity}</span>
                      <span>£{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="border-t border-white/10 pt-2 mt-2">
                    <div className="flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <span className="text-[#FF6B4A]">£{cartTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Order Type */}
            <div>
              <label className="block text-sm font-medium mb-3">Order Type</label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setOrderType('collection')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    orderType === 'collection' 
                      ? 'border-[#FF6B4A] bg-[#FF6B4A]/10' 
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <Utensils className="w-6 h-6 mx-auto mb-2" />
                  <span className="block font-medium">Collection</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('delivery')}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    orderType === 'delivery' 
                      ? 'border-[#FF6B4A] bg-[#FF6B4A]/10' 
                      : 'border-white/10 hover:border-white/30'
                  }`}
                >
                  <Truck className="w-6 h-6 mx-auto mb-2" />
                  <span className="block font-medium">Delivery</span>
                </button>
              </div>
            </div>
            
            {/* Address (if delivery) */}
            {orderType === 'delivery' && (
              <div>
                <label className="block text-sm font-medium mb-2">Delivery Address</label>
                <textarea placeholder="Enter your full address..." rows={3} className="form-input resize-none" />
              </div>
            )}
            
            {/* Phone */}
            <div>
              <label className="block text-sm font-medium mb-2">Phone Number</label>
              <Input placeholder="020 0000 0000" className="form-input border-0" />
            </div>
            
            {/* Notes */}
            <div>
              <label className="block text-sm font-medium mb-2">Special Instructions</label>
              <textarea placeholder="Any allergies or special requests..." rows={2} className="form-input resize-none" />
            </div>
            
            <Button 
              onClick={() => {
                alert('Order placed successfully! Your order number is ORD-' + Math.floor(Math.random() * 1000000));
                setCart([]);
                setIsCheckoutOpen(false);
              }}
              disabled={cart.length === 0 || !orderType}
              className="btn btn-primary w-full"
            >
              Place Order
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
