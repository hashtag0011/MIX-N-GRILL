export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'burgers' | 'wings' | 'wraps' | 'chicken' | 'pizza' | 'desserts' | 'curries' | 'boxes' | 'bbq' | 'popcorn' | 'ribs' | 'peri' | 'kids' | 'extras' | 'milkshakes';
  image: string;
  isNew?: boolean;
  isVegan?: boolean;
  isSpicy?: boolean;
  options?: {
    name: string;
    price: number;
  }[];
}

export interface CartItem extends MenuItem {
  quantity: number;
  selectedOptions?: string[];
}

export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  address?: string;
}

export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  type: 'delivery' | 'collection';
  address?: string;
  phone: string;
  notes?: string;
  createdAt: Date;
  estimatedTime?: Date;
}

export interface OrderUpdate {
  orderId: string;
  status: OrderStatus;
  message: string;
  timestamp: Date;
}
